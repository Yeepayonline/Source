﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Yeepay_OnlinePc_C
{
    public partial class ResultShow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            data.Value = Request["data"].Replace("{","").Replace("}","").Replace(",","\n").Replace(":",":      ").Replace("\"\"","");
            type.Value = Request["type"];
        }
    }
}