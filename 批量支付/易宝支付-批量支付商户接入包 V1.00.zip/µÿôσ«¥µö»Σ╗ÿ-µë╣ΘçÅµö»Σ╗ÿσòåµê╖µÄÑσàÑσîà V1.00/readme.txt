1、JAVA版demo运行：将文件夹放在tomcat的webapps目录下即可；然后启动tomcat，在浏览器中敲入：http://localhost:端口号/BatchPay，即可运行demo。

2、JAVA版的源代码放在该目录下：BatchPay/WEB-INF/classes/com/yeepay/

3、测试商编密钥:
	商户编号：10011830666
	商户密钥：98S39x7q6ap7fDE6H8Xtz32M24r1B90JL97839M32692d91E8y58587duq96
