package com.yeepay;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Iterator;
import java.net.URLEncoder;
import java.net.URLDecoder;

import com.yeepay.DigestUtil;
import com.yeepay.HttpUtils;
import com.yeepay.Configuration;

public class YeepayService {

	/**
	 * getP1_MerId() : 取得商户编号方法
	 */
	public static String getP1_MerId() {
		return Configuration.getInstance().getValue("p1_MerId");
	}

	/**
	 * getKeyValue() : 取得商户密钥方法
	 */
	public static String getKeyValue() {
		return Configuration.getInstance().getValue("keyValue");
	}

	/**
	 * getRequestURL() : 取得下单地址方法
	 */
	public static String getRequestURL() {
		return Configuration.getInstance().getValue("requestURL");
	}

	/**
	 * formatString(String text) : 字符串格式化方法
	 */
	public static String formatString(String text) {
		return (text == null ? "" : text.trim());
	}


	/**
	 * getPayURL() : 生成支付链接
	 */
	public static String getPayURL(Map<String, String> params) {

		System.out.println("##### getPayURL() #####");

		String p0_Cmd			= "BatchBuy";
		String p1_MerId         = getP1_MerId();
		String keyValue			= getKeyValue();
		String requestURL		= getRequestURL();

		String p2_BatchNO       = formatString(params.get("p2_BatchNO"));
		String p3_BatchNum      = formatString(params.get("p3_BatchNum"));
		String p4_BatchAmt      = formatString(params.get("p4_BatchAmt"));
		String p5_BatchDetail   = formatString(params.get("p5_BatchDetail"));
		String p6_Cur           = formatString(params.get("p6_Cur"));
		String p7_Url           = formatString(params.get("p7_Url"));
		String pa_MP            = formatString(params.get("pa_MP"));
		String pd_FrpId         = formatString(params.get("pd_FrpId"));
		String pm_Period        = formatString(params.get("pm_Period"));
		String pn_Unit          = formatString(params.get("pn_Unit"));

		String[] strArr			= new String[] {p0_Cmd, p1_MerId, p2_BatchNO, p3_BatchNum, p4_BatchAmt, 
							p5_BatchDetail, p6_Cur, p7_Url, pa_MP, pd_FrpId, pm_Period, pn_Unit};
		
		System.out.println("params=" + params);
		for(int i = 0; i < strArr.length; i++) {
			System.out.print(strArr[i]);
		}
		System.out.println();

		String hmac				= DigestUtil.getHmac(strArr, keyValue);

		Map<String, String> requestParams = new HashMap<String, String>();

		try {
			p0_Cmd			= URLEncoder.encode(p0_Cmd, 		"GBK");
			p1_MerId        = URLEncoder.encode(p1_MerId, 		"GBK");
			p2_BatchNO      = URLEncoder.encode(p2_BatchNO, 	"GBK");
			p3_BatchNum     = URLEncoder.encode(p3_BatchNum, 	"GBK");
			p4_BatchAmt     = URLEncoder.encode(p4_BatchAmt, 	"GBK");
			p5_BatchDetail  = URLEncoder.encode(p5_BatchDetail, "GBK");
			p6_Cur          = URLEncoder.encode(p6_Cur, 		"GBK");
			p7_Url          = URLEncoder.encode(p7_Url, 		"GBK");
			pa_MP           = URLEncoder.encode(pa_MP, 			"GBK");
			pd_FrpId        = URLEncoder.encode(pd_FrpId, 		"GBK");
			pm_Period       = URLEncoder.encode(pm_Period, 		"GBK");
			pn_Unit         = URLEncoder.encode(pn_Unit, 		"GBK");
			hmac			= URLEncoder.encode(hmac, 			"GBK");
		} catch(Exception e) {
			e.printStackTrace();
		}

		StringBuffer payURL = new StringBuffer();

		payURL.append(requestURL).append("?");
		payURL.append("p0_Cmd=").append(p0_Cmd);
		payURL.append("&p1_MerId=").append(p1_MerId);
		payURL.append("&p2_BatchNO=").append(p2_BatchNO);
		payURL.append("&p3_BatchNum=").append(p3_BatchNum);
		payURL.append("&p4_BatchAmt=").append(p4_BatchAmt);
		payURL.append("&p5_BatchDetail=").append(p5_BatchDetail);
		payURL.append("&p6_Cur=").append(p6_Cur);
		payURL.append("&p7_Url=").append(p7_Url);
		payURL.append("&pa_MP=").append(pa_MP);
		payURL.append("&pd_FrpId=").append(pd_FrpId);
		payURL.append("&pm_Period=").append(pm_Period);
		payURL.append("&pn_Unit=").append(pn_Unit);
        payURL.append("&hmac=").append(hmac);                  

		System.out.println("payURL : " + payURL);
		
		return (payURL.toString());
	}

	
	/**
	 * verifyCallbackHmac() : 验证回调参数是否有效
	 */
	public static boolean verifyCallbackHmac(String[] stringValue, String hmacFromYeepay) {

		System.out.println("##### verifyCallbackHmac() #####");

		String keyValue			= getKeyValue();

		StringBuffer sourceData	= new StringBuffer();
		for(int i = 0; i < stringValue.length; i++) {
			sourceData.append(stringValue[i]);
		}

		String localHmac		= DigestUtil.getHmac(stringValue, keyValue);

		System.out.println("sourceData : " + sourceData);
		System.out.println("hmacYeepay : " + hmacFromYeepay);
		System.out.println("localHmac : " + localHmac);

		StringBuffer hmacSource	= new StringBuffer();
		for(int i = 0; i < stringValue.length; i++) {
			hmacSource.append(stringValue[i]);
		}

		return (localHmac.equals(hmacFromYeepay) ? true : false);
	}
}
