<html>
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<title>4.2 绑定银行卡短验发送</title>
</head>
	<body>
		<br>
		<br>
		<table width="70%" border="0" align="center" cellpadding="10" cellspacing="0" style="border:solid 1px #107929">
			<tr>
		  		<th align="center" height="20" colspan="3" bgcolor="#6BBE18">
					4.2 绑定银行卡短验发送
				</th>
		  	</tr> 

			<form method="post" action="sendSms.php" target="_blank" accept-charset="UTF-8">
				<tr >
					<td width="15%" align="left">&nbsp;绑卡请求号</td>
					<td width="5%"  align="center"> : &nbsp;</td> 
					<td width="80%" align="left"> 
						<input size="90" type="text" name="requestid" />
					</td>
				</tr>

				<tr >
					<td width="10%" align="left">&nbsp;</td>
					<td width="5%"  align="center">&nbsp;</td> 
					<td width="85%" align="left"> 
						<input type="submit" value="提交" />
					</td>
				</tr>

			</form>
		</table>
</body>
</html>