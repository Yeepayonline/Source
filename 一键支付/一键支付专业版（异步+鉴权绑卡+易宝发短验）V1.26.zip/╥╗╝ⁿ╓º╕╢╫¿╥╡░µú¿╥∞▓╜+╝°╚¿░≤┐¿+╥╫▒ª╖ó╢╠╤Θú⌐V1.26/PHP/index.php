
<html>
<head>
	<meta charset="UTF-8">
	<title>异步-鉴权绑卡-易宝短验接口演示</title>
</head>
<body>
	<br> <br>
		<table width="50%" border="0" align="center" cellpadding="10" cellspacing="0" 
			   rules="rows"	style="border:solid 1px #107929">
			<tr>
		  		<th align="center" height="20" colspan="1" bgcolor="#6BBE18"> 
				异步-鉴权绑卡-易宝短验接口演示
				</th>
		  	</tr> 

			<tr >
				<td align="left" >
					<a href="bindCardRequest.php" target="_blank" style="text-decoration:none;">
						4.1 鉴权绑卡请求
					</a>
				</td>
			</tr>

			<tr >
				<td align="left" >
					<a href="bindSms.php" target="_blank" style="text-decoration:none;">
						4.2 绑定银行卡短验发送
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="checkSms.php" target="_blank" style="text-decoration:none;">
						4.3 校验绑定银行卡短验
					</a>
				</td>
			</tr>
			<tr >
				<td align="left">
					<a href="bindBankcardList.php" target="_blank" style="text-decoration:none;">
						4.4 查询绑卡信息列表
					</a>
				</td>
			</tr>
			<tr >
				<td align="left">
					<a href="bindPayRequest.php" target="_blank" style="text-decoration:none;">
						4.5 绑卡支付请求
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="message.php" target="_blank" style="text-decoration:none;">
						4.6 发送短信验证码
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="paymentConfirm.php" target="_blank" style="text-decoration:none;">
						4.7 确认支付
					</a>
				</td>
			</tr>
      <tr >
				<td align="left">
					<a href="query.php" target="_blank" style="text-decoration:none;">
						4.8 支付结果查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="bankCardCheck.php" target="_blank" style="text-decoration:none;">
						4.10 银行卡信息查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="refund.php" target="_blank" style="text-decoration:none;">
						5.1 退货退款
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="singleQuery.php" target="_blank" style="text-decoration:none;">
						5.2 交易记录查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="refundQuery.php" target="_blank" style="text-decoration:none;">
						5.3 退货退款记录查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="payClearData.php" target="_blank" style="text-decoration:none;">
						5.4 获取消费清算对账单记录
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="refundClearData.php" target="_blank" style="text-decoration:none;">
						5.5 获取退款清算对账记录
					</a>
				</td>
			</tr>

		</table>
</body>
</html>
