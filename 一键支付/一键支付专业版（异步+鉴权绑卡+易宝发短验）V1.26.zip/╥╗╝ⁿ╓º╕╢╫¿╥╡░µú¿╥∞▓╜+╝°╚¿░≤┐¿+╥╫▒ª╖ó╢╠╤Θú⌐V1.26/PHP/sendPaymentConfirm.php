<?php
//确认支付
include("yeepay/yeepayMPay.php");
include("config.php");
$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);
$orderid = trim($_POST['orderid']);
$validatecode = trim($_POST['validatecode']);
$data = $yeepay-> confirmPay($orderid,$validatecode);
if( array_key_exists('error_code', $data))	
return;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>4.7 确认支付结果</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
					4.7 确认支付结果
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户订单号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['orderid'];?>  </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">orderid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;易宝流水号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['yborderid'];?>  </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">yborderid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;银行卡类型</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['bankcardtype'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">bankcardtype</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;所属银行</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['bankname'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">bankname</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;卡号后四位</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left">  <?php echo $data['cardlast'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">cardlast</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;手机号码</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['phone'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">phone</td> 
			</tr>
		</table>

	</body>
</html>
