<?php
include 'config.php';
include 'yeepay/yeepayMPay.php';

$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);

$order_id          =  trim($_POST['orderid']);
$bind_id           =  trim($_POST['bindid']);
$transtime         =  intval($_POST['transtime']);
$product_catalog   =  trim($_POST['productcatalog']);
$amount            =  intval($_POST['amount']);
$identity_type     =  intval($_POST['identitytype']);
$identity_id       =  trim($_POST['identityid']);
$user_ip           =  trim($_POST['userip']);
$terminaltype      =  intval($_POST['terminaltype']);
$terminalid        =  trim($_POST['terminalid']);
$callbackurl       =  trim($_POST['callbackurl']);
$product_name      =  trim($_POST['productname']);
$product_desc      =  trim($_POST['productdesc']);
$currency          =  intval($_POST['currency']);
$orderexpdate      =  intval($_POST['orderexpdate']);
$riskcontrolinfo   =  trim($_POST['riskcontrolinfo']);

$data = $yeepay->bindPayRequest($bind_id,$order_id,$transtime,$amount,$product_catalog,$identity_id,$identity_type,
$user_ip,$terminaltype,$terminalid,$callbackurl,$currency,$product_name,$product_desc,$orderexpdate,$riskcontrolinfo);

if( array_key_exists('error_code', $data))	
return;

 ?> 


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>4.5 绑卡支付请求</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
					4.5 绑卡支付请求返回
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left">  <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户订单号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['orderid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">orderid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;手机号码</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['phone'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">phone</td> 
			</tr>

			<tr>
				<td width="15%" align="left" rowspan="6">&nbsp;是否发送短信</td>
				<td width="5%"  align="center" rowspan="6"> : </td> 
				<td width="60%" align="left" rowspan="6">
					<?php echo $data['smsconfirm'];?>
					<span style="font-size:12px; color:#FF0000; font-weight:100;"> 
						- 0：无需发送	- 1：必须发送
					</span>
				</td>
				<td width="5%"  align="center" rowspan="6"> - </td> 
				<td width="25%" align="left" rowspan="6">smsconfirm</td> 
			</tr>

		</table>

	</body>
</html>
