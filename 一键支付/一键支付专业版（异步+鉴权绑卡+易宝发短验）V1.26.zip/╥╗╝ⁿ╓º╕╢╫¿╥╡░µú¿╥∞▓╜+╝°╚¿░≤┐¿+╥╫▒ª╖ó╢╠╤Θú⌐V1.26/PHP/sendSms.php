<?php
//发送绑卡请求短验
include("yeepay/yeepayMPay.php");
include("config.php");
$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);
$requestid = trim($_POST['requestid']);
$data = $yeepay->sendSms($requestid);
if( array_key_exists('error_code', $data))	
return;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>4.2 绑定银行卡短验发送</title>
</head>
	<body>
		<br /> <br />
		<table width="70%" border="0" align="center" cellpadding="5" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
					4.2 绑定银行卡短验发送
				</th>
		  	</tr>

			<tr>
				<td width="25%" align="left">&nbsp商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="25%" align="left">&nbsp;绑卡请求号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['requestid'];?>  </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">requestid</td> 
			</tr>

			

		</table>

	</body>
</html>