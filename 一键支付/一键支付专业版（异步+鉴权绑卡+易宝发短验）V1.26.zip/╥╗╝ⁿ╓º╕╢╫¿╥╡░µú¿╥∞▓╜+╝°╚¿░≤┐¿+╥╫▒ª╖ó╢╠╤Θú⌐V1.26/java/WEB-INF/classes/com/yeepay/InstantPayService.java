package com.yeepay;

import java.util.Map;
import java.util.TreeMap;
import java.util.HashMap;
import java.net.URLEncoder;
import java.io.InputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import com.yeepay.AES;
import com.yeepay.RSA;
import com.yeepay.EncryUtil;
import com.yeepay.RandomUtil;
import com.yeepay.Configuration;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.HttpClient;

/**
 * 一键支付接口范例-专业版异步鉴权易宝短验
 * @author	：wangjie   
 * @since	：2015-09-10 
 */

public class InstantPayService {
	
	/**
	 * 取得商户编号
	 */
	public static String getMerchantAccount() {
		return Configuration.getInstance().getValue("merchantAccount");
	}
	
	/**
	 * 取得商户私钥
	 */
	public static String getMerchantPrivateKey() {
		return Configuration.getInstance().getValue("merchantPrivateKey");
	}

	/**
	 * 取得商户AESKey
	 */
	public static String getMerchantAESKey() {
		return (RandomUtil.getRandom(16));
	}

	/**
	 * 取得易宝公玥
	 */
	public static String getYeepayPublicKey() {
		return Configuration.getInstance().getValue("yeepayPublicKey");
	}

	/**
	 * 格式化字符串
	 */
	public static String formatString(String text) {
		return (text == null ? "" : text.trim());
	}

	/**
	 * String2Integer
	 */
	public static int String2Int(String text) throws NumberFormatException {
		return text == null ? 0 : Integer.valueOf(text);
	}

	/**
	 * String2Long
	 */
	public static Long String2Long(String text) throws NumberFormatException {
		return text == null ? 0 : Long.valueOf(text);
	}

	/**
	 * 鉴权绑卡接口演示 
	 */
	public static String getRequestURL() {
		return Configuration.getInstance().getValue("requestURL");
	}

	/**
	 * 绑定银行卡短验发送 
	 */
	public static String getSendsmsURL() {
		return Configuration.getInstance().getValue("sendsmsURL");
	}

	/**
	 * 校验绑定银行卡短验
	 */
	public static String getChecksmsURL() {
		return Configuration.getInstance().getValue("checksmsURL");
	}
	
	/**
	 * 查询绑卡信息列表 
	 */
	public static String getListURL() {
		return Configuration.getInstance().getValue("listURL");
	}

	/**
	 * 绑卡支付请求
	 */
	public static String getPayrequestURL() {
		return Configuration.getInstance().getValue("payrequestURL");
	}
	
	/**
	 * 发送短信验证码 
	 */
	public static String getRequestpayURL() {
		return Configuration.getInstance().getValue("requestpayURL");
	}
	
	/**
	 * 确认支付
	 */
	public static String getSendpaysmsURL() {
		return Configuration.getInstance().getValue("sendsmspayURL");
	}

	/**
	 * 支付结果查询
	 */
	public static String getResultqueryURL() {
		return Configuration.getInstance().getValue("resultqueryURL");
	}
	
	/**
	 * 银行卡信息查询请求地址 
	 */
	public static String getBankCardCheckURL() {
		return Configuration.getInstance().getValue("bankCardCheckURL");
	}
	
	/**
	 * 解析http请求返回
	 */
	public static Map<String, String> parseHttpResponseBody(int statusCode, String responseBody) throws Exception {

		String merchantPrivateKey	= getMerchantPrivateKey();
		String yeepayPublicKey		= getYeepayPublicKey();

		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";

		if(statusCode != 200) {
			customError	= "Request failed, response code : " + statusCode;
			result.put("customError", customError);
			return (result);
		}

		Map<String, String> jsonMap	= JSON.parseObject(responseBody, 
											new TypeReference<TreeMap<String, String>>() {});

		if(jsonMap.containsKey("error_code")) {
			result	= jsonMap;
			return (result);
		}

		String dataFromYeepay		= formatString(jsonMap.get("data"));
		String encryptkeyFromYeepay	= formatString(jsonMap.get("encryptkey"));

		boolean signMatch = EncryUtil.checkDecryptAndSign(dataFromYeepay, encryptkeyFromYeepay, 
										yeepayPublicKey, merchantPrivateKey);
		if(!signMatch) {
			customError	= "Sign not match error";
			result.put("customError",	customError);
			return (result);
		}

		String yeepayAESKey		= RSA.decrypt(encryptkeyFromYeepay, merchantPrivateKey);
		String decryptData		= AES.decryptFromBase64(dataFromYeepay, yeepayAESKey);

		result	= JSON.parseObject(decryptData, new TypeReference<TreeMap<String, String>>() {});

		return(result);
	}

	/**
	 * bindcard() : 鉴权绑卡接口 wangjie
	 */

	public static Map<String, String> bindcard(Map<String, String> params) {

		System.out.println("##### bindcard() #####");
		
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回
		
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String refundURL			= getRequestURL();
		
		String merchantaccount              = formatString(params.get("merchantaccount"));
		String cardno		= formatString(params.get("cardno"));
		String idcardtype               = formatString(params.get("idcardtype"));
		String idcardno				= formatString(params.get("idcardno"));
		String username				= formatString(params.get("username"));
		String phone              = formatString(params.get("phone"));
		String requestid		= formatString(params.get("requestid"));
		String userip               = formatString(params.get("userip"));
		String cvv2				= formatString(params.get("cvv2"));
		String validthru				= formatString(params.get("validthru"));
		String identityid              = formatString(params.get("identityid"));
		String terminalid				= formatString(params.get("terminalid"));
		String bankbranch				= formatString(params.get("bankbranch"));
		String province				= formatString(params.get("province"));
		String city				= formatString(params.get("city"));
		
		int identitytype              	= 0; 
		int terminaltype	        	= 0; 
		
		try {
			//amount、currency是必填参数
			if(params.get("identitytype") == null) {
				throw new Exception("identitytype is null!!!!!");
			} else {
				identitytype 	 = String2Int(params.get("identitytype"));
			}

			if(params.get("terminaltype") == null) {
				throw new Exception("terminaltype is null!!!!!");
			} else {
				terminaltype  = String2Int(params.get("terminaltype"));
			}

		} catch(Exception e) {
			e.printStackTrace();
			customError	= "******input params error : String to Int Exception - " +
								"], identitytype=[" + identitytype +
								"], terminaltype=[" + terminaltype + "]" + e.toString();
			result.put("customError", customError);
			return (result);
		}

		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("cardno",	cardno);
		dataMap.put("idcardtype", 		idcardtype);
		dataMap.put("idcardno", 		idcardno);
		dataMap.put("username", 		username);
		dataMap.put("phone", 		phone);
		dataMap.put("requestid",	requestid);
		dataMap.put("userip", 		userip);
		dataMap.put("cvv2", 		cvv2);
		dataMap.put("validthru", 		validthru);
		dataMap.put("identityid", 		identityid);
		dataMap.put("identitytype",	identitytype);
		dataMap.put("terminaltype", 		terminaltype);
		dataMap.put("terminalid", 		terminalid);
		dataMap.put("bankbranch", 		bankbranch);
		dataMap.put("province", 		province);
		dataMap.put("city", 		city);
				
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("params : " + params);
		System.out.println("refundURL : " + refundURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(refundURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			System.out.println("data : " + data);
			System.out.println("encryptkey : " + encryptkey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};

			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught an Exception. " + e.toString();
			result.put("customError", 	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	
	/**
	 * sendsms() : 绑定银行卡短验发送 wangjie
	 */

	public static Map<String, String> sendsms(Map<String, String> params) {

		System.out.println("##### sendsms() #####");
		
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回
		
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String RefundQueryURL		= getSendsmsURL();
		
		String merchantaccount              = formatString(params.get("merchantaccount"));
		String cardno		= formatString(params.get("cardno"));
		String requestid		= formatString(params.get("requestid"));
		
		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("cardno",	cardno);
		dataMap.put("requestid",	requestid);
				
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("params : " + params);
		System.out.println("RefundQueryURL : " + RefundQueryURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(RefundQueryURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			System.out.println("data : " + data);
			System.out.println("encryptkey : " + encryptkey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};

			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught an Exception. " + e.toString();
			result.put("customError", 	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	/**
	 * checksms() : 校验绑定银行卡短验 wangjie
	 */

	public static Map<String, String> checksms(Map<String, String> params) {

		System.out.println("##### checksms() #####");
		
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回
		
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String refundClearDataURL	= getChecksmsURL();
		
		String merchantaccount              = formatString(params.get("merchantaccount"));
		String requestid		= formatString(params.get("requestid"));
		String validatecode              = formatString(params.get("validatecode"));

		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("requestid",	requestid);
		dataMap.put("validatecode", 		validatecode);
		
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("params : " + params);
		System.out.println("refundClearDataURL : " + refundClearDataURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(refundClearDataURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			System.out.println("data : " + data);
			System.out.println("encryptkey : " + encryptkey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};

			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught an Exception. " + e.toString();
			result.put("customError", 	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	
	
	/**
	 * querlist() : 查询绑卡信息列表接口 wangjie
	 */

	public static Map<String, String> querlist(Map<String, String> params) {
		
		System.out.println("##### querlist() #####");
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";
		
		String merchantaccount		= getMerchantAccount();
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String bankCardCheckURL		= getListURL();
		
		//String merchantaccount              = formatString(params.get("merchantaccount"));
		String identityid              = formatString(params.get("identityid"));
		int identitytype              	= 0; 
		
		try {
			//amount、currency是必填参数
			if(params.get("identitytype") == null) {
				throw new Exception("identitytype is null!!!!!");
			} else {
				identitytype 	 = String2Int(params.get("identitytype"));
			}

		} catch(Exception e) {
			e.printStackTrace();
			customError	= "******input params error : String to Int Exception - " +
								"], identitytype=[" + identitytype + "]" + e.toString();
			result.put("customError", customError);
			return (result);
		}
		
		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("identityid", 		identityid);
		dataMap.put("identitytype",	identitytype);

		String sign	= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);
				
		System.out.println("bankCardCheckURL : " + bankCardCheckURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		GetMethod getMethod			= new GetMethod();
		
		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			String url				= bankCardCheckURL + 
									  "?merchantaccount=" + URLEncoder.encode(merchantaccount, "UTF-8") + 
									  "&data=" + URLEncoder.encode(data, "UTF-8") +
									  "&encryptkey=" + URLEncoder.encode(encryptkey, "UTF-8");
			getMethod				= new GetMethod(url);
			int statusCode			= httpClient.executeMethod(getMethod);
			String responseBody		= getMethod.getResponseBodyAsString();

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError		= "Caught an Exception. " + e.toString();
			result.put("customError", customError);
			e.printStackTrace();
		} finally {
			getMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	/**
	 * payrequest() : 鉴权绑卡接口 wangjie
	 */

	public static Map<String, String> payrequest(Map<String, String> params) {

		System.out.println("##### payrequest() #####");
		
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回
		
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String payrequestURL		= getPayrequestURL();

		String merchantaccount              = formatString(params.get("merchantaccount"));
		String bindid		= formatString(params.get("bindid"));
		String orderid               = formatString(params.get("orderid"));
		String productcatalog		= formatString(params.get("productcatalog"));
		String productname               = formatString(params.get("productname"));
		String productdesc				= formatString(params.get("productdesc"));
		String identityid              = formatString(params.get("identityid"));
		String terminalid				= formatString(params.get("terminalid"));
		String other				= formatString(params.get("other"));
		String userip				= formatString(params.get("userip"));
		String callbackurl				= formatString(params.get("callbackurl"));
		
		int transtime              	= 0; 
		int currency              	= 0; 
		int amount              	= 0; 
		int identitytype              	= 0; 
		int terminaltype	        	= 0; 
		int orderexpdate	        	= 0; 
		
		try {
			//amount、currency是必填参数
			if(params.get("transtime") == null) {
				throw new Exception("transtime is null!!!!!");
			} else {
				transtime 	 = String2Int(params.get("transtime"));
			}
			
			if(params.get("currency") == null) {
				throw new Exception("currency is null!!!!!");
			} else {
				currency 	 = String2Int(params.get("currency"));
			}
			
			if(params.get("amount") == null) {
				throw new Exception("amount is null!!!!!");
			} else {
				amount 	 = String2Int(params.get("amount"));
			}
			
			if(params.get("identitytype") == null) {
				throw new Exception("identitytype is null!!!!!");
			} else {
				identitytype 	 = String2Int(params.get("identitytype"));
			}

			if(params.get("terminaltype") == null) {
				throw new Exception("terminaltype is null!!!!!");
			} else {
				terminaltype  = String2Int(params.get("terminaltype"));
			}

			if(params.get("orderexpdate") == null) {
				throw new Exception("orderexpdate is null!!!!!");
			} else {
				orderexpdate  = String2Int(params.get("orderexpdate"));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			customError	= "******input params error : String to Int Exception - " +
					"], transtime=[" + transtime +
					"], currency=[" + currency +
					"], amount=[" + amount +
					"], identitytype=[" + identitytype +
					"], terminaltype=[" + terminaltype + 
					"], orderexpdate=[" + orderexpdate + 
					"]" + e.toString();
			result.put("customError", customError);
			return (result);
		}

		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();

		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("bindid",	bindid);
		dataMap.put("orderid", 		orderid);
		dataMap.put("transtime", 		transtime);
		dataMap.put("currency", 		currency);
		dataMap.put("amount", 		amount);
		dataMap.put("productcatalog",	productcatalog);
		dataMap.put("productname", 		productname);
		dataMap.put("productdesc", 		productdesc);
		dataMap.put("identityid", 		identityid);
		dataMap.put("identitytype",	identitytype);
		dataMap.put("terminaltype", 		terminaltype);
		dataMap.put("terminalid", 		terminalid);
		dataMap.put("other", 		other);
		dataMap.put("userip", 		userip);
		dataMap.put("callbackurl", 		callbackurl);
		dataMap.put("orderexpdate", 		orderexpdate);
		
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("params : " + params);
		System.out.println("payrequestURL : " + payrequestURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(payrequestURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			System.out.println("data : " + data);
			System.out.println("encryptkey : " + encryptkey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};

			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught an Exception. " + e.toString();
			result.put("customError", 	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}
	/**
	 * confirmpay() : 确认支付接口 wangjie
	 */

	public static Map<String, String> confirmpay(Map<String, String> params) {

		System.out.println("##### confirmpay() #####");
		
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回
		
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String sendsmspayURL		= getSendpaysmsURL();
		
		String merchantaccount              = formatString(params.get("merchantaccount"));
		String orderid		= formatString(params.get("orderid"));
		String validatecode               = formatString(params.get("validatecode"));

		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("orderid",	orderid);
		dataMap.put("validatecode",	validatecode);
				
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("params : " + params);
		System.out.println("sendsmspayURL : " + sendsmspayURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(sendsmspayURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			System.out.println("data : " + data);
			System.out.println("encryptkey : " + encryptkey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};

			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught an Exception. " + e.toString();
			result.put("customError", 	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	
	/**
	 * resultquery() : 支付结果查询 wangjie
	 */

	public static Map<String, String> resultquery(Map<String, String> params) {
		
		System.out.println("##### resultquery() #####");
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";
		
		String merchantaccount		= getMerchantAccount();
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String resultqueryURL		= getResultqueryURL();
		
		String orderid              = formatString(params.get("orderid"));
		
		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("orderid", 		orderid);

		String sign	= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);
				
		System.out.println("resultqueryURL : " + resultqueryURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		GetMethod getMethod			= new GetMethod();
		
		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			String url				= resultqueryURL + 
									  "?merchantaccount=" + URLEncoder.encode(merchantaccount, "UTF-8") + 
									  "&data=" + URLEncoder.encode(data, "UTF-8") +
									  "&encryptkey=" + URLEncoder.encode(encryptkey, "UTF-8");
			getMethod				= new GetMethod(url);
			int statusCode			= httpClient.executeMethod(getMethod);
			String responseBody		= getMethod.getResponseBodyAsString();

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError		= "Caught an Exception. " + e.toString();
			result.put("customError", customError);
			e.printStackTrace();
		} finally {
			getMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	/**
	 * bankCardCheck() : 银行卡查询方法   wangjie
	 */

	public static Map<String, String> bankCardCheck(String cardno) {
		
		System.out.println("##### bankCardCheck() #####");
		
		String merchantaccount		= getMerchantAccount();
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String bankCardCheckURL		= getBankCardCheckURL();
		
		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 	merchantaccount);
		dataMap.put("cardno", 			cardno);
				
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("bankCardCheckURL : " + bankCardCheckURL);
		System.out.println("dataMap : " + dataMap);

		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(bankCardCheckURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};
			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught Exception!" + e.toString();
			result.put("customError",	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}
	
	/**
	 * requestpaysms() : 鉴权绑卡接口 wangjie
	 */

	public static Map<String, String> requestpaysms(Map<String, String> params) {

		System.out.println("##### requestpaysms() #####");
		
		Map<String, String> result	= new HashMap<String, String>();
		String customError			= "";	// 自定义，非接口返回
		
		String merchantPrivateKey	= getMerchantPrivateKey();
		String merchantAESKey		= getMerchantAESKey();
		String yeepayPublicKey		= getYeepayPublicKey();
		String requestpayURL		= getRequestpayURL();
		
		String merchantaccount              = formatString(params.get("merchantaccount"));
		String orderid		= formatString(params.get("orderid"));
		
		TreeMap<String, Object> dataMap	= new TreeMap<String, Object>();
		dataMap.put("merchantaccount", 		merchantaccount);
		dataMap.put("orderid",	orderid);
		
		String sign					= EncryUtil.handleRSA(dataMap, merchantPrivateKey);
		dataMap.put("sign", sign);

		System.out.println("params : " + params);
		System.out.println("requestpayURL : " + requestpayURL);
		System.out.println("dataMap : " + dataMap);

		HttpClient httpClient		= new HttpClient();
		PostMethod postMethod		= new PostMethod(requestpayURL);

		try {
			String jsonStr			= JSON.toJSONString(dataMap);
			String data				= AES.encryptToBase64(jsonStr, merchantAESKey);
			String encryptkey		= RSA.encrypt(merchantAESKey, yeepayPublicKey);

			System.out.println("data : " + data);
			System.out.println("encryptkey : " + encryptkey);

			NameValuePair[] datas	= {new NameValuePair("merchantaccount", merchantaccount),
									   new NameValuePair("data", data),
									   new NameValuePair("encryptkey", encryptkey)};

			postMethod.setRequestBody(datas);

			int statusCode			= httpClient.executeMethod(postMethod);
			byte[] responseByte		= postMethod.getResponseBody();
			String responseBody		= new String(responseByte, "UTF-8");

			result					= parseHttpResponseBody(statusCode, responseBody);

		} catch(Exception e) {
			customError	= "Caught an Exception. " + e.toString();
			result.put("customError", 	customError);
			e.printStackTrace();
		} finally {
			postMethod.releaseConnection();
		}

		System.out.println("result : " + result);

		return (result);
	}

	
}