
<html>
<head>
	<meta charset="UTF-8">
	<title>协议扣款接口演示</title>
</head>
<body>
	<br> <br>
		<table width="50%" border="0" align="center" cellpadding="10" cellspacing="0" 
			   rules="rows"	style="border:solid 1px #107929">
			<tr>
		  		<th align="center" height="20" colspan="1" bgcolor="#6BBE18"> 
					协议扣款接口演示
				</th>
		  	</tr> 

			

			<tr >
				<td align="left" >
					<a href="debitRequest.php" target="_blank" style="text-decoration:none;">
						5.1 储蓄卡支付请求
					</a>
				</td>
			</tr>

	
      <tr >
				<td align="left">
					<a href="query.php" target="_blank" style="text-decoration:none;">
						5.2 支付结果查询
					</a>
				</td>
			</tr>
			

			<tr >
				<td align="left">
					<a href="bankCardCheck.php" target="_blank" style="text-decoration:none;">
						5.3 银行卡信息查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="refund.php" target="_blank" style="text-decoration:none;">
						6.1 退货退款
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="singleQuery.php" target="_blank" style="text-decoration:none;">
						6.2 交易记录查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="refundQuery.php" target="_blank" style="text-decoration:none;">
						6.3 退货退款记录查询
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="payClearData.php" target="_blank" style="text-decoration:none;">
						6.4 获取消费清算对账单记录
					</a>
				</td>
			</tr>

			<tr >
				<td align="left">
					<a href="refundClearData.php" target="_blank" style="text-decoration:none;">
						6.5 获取退款清算对账记录
					</a>
				</td>
			</tr>

		</table>
</body>
</html>
