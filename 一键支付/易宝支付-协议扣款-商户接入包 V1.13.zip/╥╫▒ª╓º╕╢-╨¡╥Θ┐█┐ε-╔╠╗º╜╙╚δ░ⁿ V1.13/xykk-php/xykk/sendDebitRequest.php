<?php
//借记卡支付
include 'config.php';
include 'yeepay/yeepayMPay.php';

$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);

$cardno          =  trim($_POST['cardno']);
$idcardtype      =  trim($_POST['idcardtype']);
$idcard          =  trim($_POST['idcard']);
$owner           =  trim($_POST['owner']);
$phone           =  trim($_POST['phone']);
$order_id        =  trim($_POST['orderid']);
$transtime       =  intval($_POST['transtime']);
$amount          =  intval($_POST['amount']);
$currency       =  intval($_POST['currency']);
$product_catalog =  trim($_POST['productcatalog']);
$product_name    =  trim($_POST['productname']);
$product_desc    =  trim($_POST['productdesc']);
$user_ip         =  trim($_POST['userip']);
$terminaltype   =  intval($_POST['terminaltype']);
$terminalid     =  trim($_POST['terminalid']);
$callbackurl    =  trim($_POST['callbackurl']);
$riskcontrolinfo = trim($_POST['riskcontrolinfo']);

$data = $yeepay->debitPayRequest($cardno,$idcardtype,$idcard,$owner,$phone,$order_id,$transtime,$amount,$product_catalog,$user_ip,$terminaltype,$terminalid,$callbackurl,$currency,$product_name,
$product_desc,$riskcontrolinfo);
	
if( array_key_exists('error_code', $data))	
return;
?>
 


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>5.1 借记卡支付请求</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="20" colspan="5" bgcolor="#6BBE18">
					5.1 借记卡支付请求返回
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center">:</td> 
				<td width="30%" align="left">  <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户订单号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"> <?php echo $data['orderid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">orderid</td> 
			</tr>
			
			<tr>
				<td width="15%" align="left">&nbsp;易宝交易流水号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"> <?php echo $data['yborderid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">yborderid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;支付金额</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['amount'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">amount</td> 
			</tr>
			
						<tr>
				<td width="15%" align="left">&nbsp;银行卡类型</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['bankcardtype'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">bankcardtype</td> 
			</tr>
			
								<tr>
				<td width="15%" align="left">&nbsp;银行名称</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['bank'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">bank</td> 
			</tr>
							
								<tr>
				<td width="15%" align="left">&nbsp;银行缩写</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['bankcode'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">bankcode</td> 
			</tr>
			
											<tr>
				<td width="15%" align="left">&nbsp;支付时间</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['closetime'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">closetime</td> 
			</tr>
			
														<tr>
				<td width="15%" align="left">&nbsp;卡号后 4 位 </td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['lastno'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">lastno</td> 
			</tr>
			
														<tr>
				<td width="15%" align="left">&nbsp;状态</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left"><?php echo $data['status'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">status</td> 
			</tr>
			<tr>	
	      <td width="25%" align="left">&nbsp;错误码</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left">
					 <?php 
					 if( empty($data['errorcode']))
					 {echo '';}
					 else
					 {echo $data['errorcode'];}
					 ?>  
					 </td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">errorcode</td> 
			</tr>
			
	    <tr>
				<td width="25%" align="left">&nbsp;错误信息</td>
				<td width="5%"  align="center"> : </td> 
				<td width="30%" align="left">
					 <?php 
					 if( empty($data['errormsg']))
					 {echo '';}
					 else
					 {echo $data['errormsg'];}
					 ?>  
					 </td>
				<td width="5%"  align="center"> - </td> 
				<td width="35%" align="left">errormsg</td> 
			</tr>
	

		</table>

	</body>
</html>
