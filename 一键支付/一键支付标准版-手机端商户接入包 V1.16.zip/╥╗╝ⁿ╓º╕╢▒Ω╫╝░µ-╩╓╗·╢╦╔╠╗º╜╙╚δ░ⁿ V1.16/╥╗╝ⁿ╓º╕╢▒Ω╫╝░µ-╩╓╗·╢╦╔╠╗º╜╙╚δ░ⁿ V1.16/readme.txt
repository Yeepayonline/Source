﻿1、JAVA版demo运行：将文件夹放在tomcat的webapps目录下即可；然后启动tomcat，在浏览器中敲入：	http://localhost:8080/InstantPay-paymobile，即可运行demo。


2、JAVA版的源代码放在该目录下：/InstantPay-paymobile/src/com/yeepay/paymobile/*

3、测试商户编号、商户密钥可在该目录下获得：/InstantPay-paymobile/src/com/yeepay/paymobile/resources\merchantInfo.properties 
