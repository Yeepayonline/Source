<?php
include 'config.php';
include 'yeepay/yeepayMPay.php';

$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);

$requestid        =  trim($_POST['requestid']);
$cardno           =  trim($_POST['cardno']);
$idcardtype       =  trim($_POST['idcardtype']);
$idcardno         =  trim($_POST['idcardno']);
$username         =  trim($_POST['username']);
$phone            =  trim($_POST['phone']);
$cvv2             =  trim($_POST['cvv2']);
$validthru        =  trim($_POST['validthru']);
$identity_type    =  intval($_POST['identitytype']);
$identity_id      =  trim($_POST['identityid']);
$user_ip          =  trim($_POST['userip']);
$terminaltype     =  intval($_POST['terminaltype']);
$terminalid       =  trim($_POST['terminalid']);
$bankbranch       =  trim($_POST['bankbranch']);
$province         =  trim($_POST['province']);
$city             =  trim($_POST['city']);


$data = $yeepay->bindCardRequest($cardno,$idcardtype,$idcardno,$username,$phone,$requestid,$cvv2,$validthru,
$identity_id,$identity_type,$user_ip,$terminaltype,$terminalid,$bankbranch,$province,$city);

if( array_key_exists('error_code', $data))	
return;

?> 


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>4.1 绑卡请求</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
					4.1 绑卡请求返回
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left">  <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;绑卡请求号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['requestid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">requestid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;用户标识</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['identityid'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">identityid</td> 
			</tr>
	<tr>
				<td width="15%" align="left">&nbsp;用户标识类型</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['identitytype'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">identitytype</td> 
			</tr>
	<tr>
				<td width="15%" align="left">&nbsp;银行编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['bankcode'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">bankcode</td> 
			</tr>
				<tr>
				<td width="15%" align="left">&nbsp;手机号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['phone'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">phone</td> 
			</tr>
				<tr>
				<td width="15%" align="left">&nbsp;卡号后 4 位</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['lastno'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">lastno</td> 
			</tr>
							<tr>
				<td width="15%" align="left">&nbsp;绑卡 ID</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['bindid'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">bindid</td> 
			</tr>
		</table>

	</body>
</html>
