<?php

// 绑卡查询
include 'config.php';

$identityid = paramLimit(trim($_POST['identityid']),50);
$identitytype = paramLimit(intval($_POST['identitytype']));

$query_data = array(
					'identityid'		=>	$identityid,
					'identitytype'		=>	(int)$identitytype
);

$data = $yeepay->bankcardList($query_data);
var_dump($data);
?>
