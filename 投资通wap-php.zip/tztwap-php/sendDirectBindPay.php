<?php

// 支付请求
include 'config.php';

$orderid 		=	paramLimit(trim($_POST['orderid']),50);
$transtime 		= 	paramLimit(intval($transtime));
$currency		=	paramLimit(trim($_POST['currency']),50);
$amount 		= 	$_POST['amount'] ? intval($_POST['amount']):1;//必须大于0
$productcatalog	=	paramLimit(trim($_POST['productcatalog']),10);
$productname 	= 	paramLimit(trim($_POST['productname']),50);
$productdesc 	= 	paramLimit(trim($_POST['productdesc']),200);
$identityid 	= 	paramLimit(trim($_POST['identityid']),50);
$identitytype	= 	paramLimit(trim($_POST['identitytype']),10 );
$terminaltype	=	paramLimit(trim($_POST['terminaltype']),10 );
$terminalid		=	paramLimit(trim( $_POST['terminalid']) );
$orderexpdate 	= 	paramLimit(trim(intval($_POST['orderexpdate'])),20);
$userip 		= 	paramLimit(trim($_POST['userip']),30);
$userua			=	paramLimit(trim($_POST['userua']),200);
$callbackurl 	= 	paramLimit(trim($_POST['callbackurl']),300);
$fcallbackurl	=	paramLimit(trim($_POST['fcallbackurl']),300);
$paytypes		=	paramLimit(trim($_POST['paytypes']));
$cardno			=	paramLimit(trim($_POST['cardno']));
$idcardtype		=	paramLimit(trim($_POST['idcardtype']));
$idcard			=	paramLimit(trim($_POST['idcard']));
$owner			=	paramLimit(trim($_POST['owner']));
$version   		=	isset($_POST['version'])?$_POST['version']:0;
if(empty($idcardtype)||empty($idcard)){ //目前只支持身份证：01，当证件类型填写时，证件号必须填写
		$idcardtype	='';
		$idcard		='';
}
$query_data = array(
			'orderid'			=>	$orderid,
			'transtime'			=>	(int)$transtime,
			'currency'			=>	(int)$currency,
			'amount'			=>	(int)$amount,
			'productcatalog'	=>	$productcatalog,
			'productname'		=>	$productname,
			'productdesc'		=>	$productdesc,
			'identityid'		=>  $identityid,
			'identitytype'		=>  (int)$identitytype,
			'terminaltype'		=>  (int)$terminaltype,
			'terminalid'		=>  $terminalid,
			'orderexpdate'		=>  (int)$orderexpdate,
			'userip'			=>  $userip,
			'userua'			=>  $userua,
			'callbackurl'		=>  $callbackurl,
			'fcallbackurl'		=>	$fcallbackurl,
			'version'			=>  (int)$version,
			'paytypes'			=>	$paytypes,
			'cardno'			=>	$cardno,
			'idcardtype'		=>	$idcardtype,
			'idcard'			=>	$idcard,
			'owner'				=>	$owner,
);

//$isurl = $yeepay->directPayment($query_data,'http://mobiletest.yeepay.com/paymobile/api/pay/request'); //测试号时开启
$url	   = $yeepay->getDirectBindPayURL();
$param_arr = $yeepay->buildRequest($query_data);

$merchantaccount = isset($param_arr['merchantaccount'])?$param_arr['merchantaccount']:'';
$data			 =	isset($param_arr['data'])?$param_arr['data']:'';
$encryptkey		 =	isset($param_arr['encryptkey'])?$param_arr['encryptkey']:'';

$mobile_pay = <<<PAY
<form action="$url" method="post" id="directBindPayURL">
<input type="hidden" name="merchantaccount" value="$merchantaccount" />
<input type="hidden" name="data"		value="$data"  />
<input type="hidden" name="encryptkey"		value="$encryptkey" />
</form>
<script language="javascript" type="text/javascript">document.getElementById("directBindPayURL").submit();</script>
PAY;

echo $mobile_pay;

?>
