<?php

// 提现
include 'config.php';

$requestid = paramLimit(trim($_POST['requestid']),50);
$identityid = paramLimit(trim($_POST['identityid']),50);
$identitytype = paramLimit(intval($_POST['identitytype']),20);
$card_top = paramLimit(trim($_POST['card_top']),6);
$card_last = paramLimit(trim($_POST['card_last']),4);
$amount = paramLimit(intval($_POST['amount']),20);
#$currency	isset($_POST['currency'])?$_POST['currency']:0;
$currency = isset($_POST['currency'])?$_POST['currency']:'';
$imei = trim($_POST['imei']);
$drawtype = paramLimit(trim($_POST['drawtype']),50);
$userip = isset($_POST['userip'])?$_POST['userip']:'';
$ua		=	isset($_POST['ua'])?trim($_POST['ua']):'';

$query_data = array(
			'requestid'			=>	$requestid,
			'identityid'		=>	$identityid,
			'identitytype'		=>	(int)$identitytype,
			'card_top'			=>	$card_top,
			'card_last'			=>	$card_last,
			'amount'			=>	(int)$amount,
			'currency'			=>	(int)$currency,
			'drawtype'			=>	$drawtype,
			'imei'				=>	$imei,
			'userip'			=>	$userip,
			'ua'				=>	$ua,
);

$data = $yeepay->withdraw($query_data);

var_dump($data);
?>
