<?php
// 银行卡信息查询
include 'config.php';
$cardno = paramLimit(trim($_POST['cardno']),200);
$query_data = array(
					'cardno'			=>	$cardno,
);
$data = $yeepay->bankcardCheck($query_data);
var_dump($data);
?>
