<?php
// 提现查询
include 'config.php';

$requestid = paramLimit(trim($_POST['requestid']),50);
$ybdrawflowid = paramLimit(trim($_POST['ybdrawflowid']),200);
$query_data = array(
			'requestid'			=>	$requestid,
			'ybdrawflowid'		=>	$ybdrawflowid
);

$data = $yeepay->withdrawQuery($query_data);

var_dump($data);
?>