<?php
header("Content-type:text/html;charset=utf-8;");
/*
*#商户编号
10000419568
#商户公钥
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCKxayKB/TqDXtcKaObOPPzVL3r++ghEP45nai9cjG0JQt9m0F5+F8RVygizxS83iBTHd5bJbrMPLDh3GvjGm1bbJhzO4m2bF2fQm2uJ0C3ckdm9AZK8fqzcncpu2dy1zFyucFyHhKIgZryqfW5PS3G9UohS4698qA5j4dceWf5PwIDAQAB
#商户私钥
MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAIrFrIoH9OoNe1wpo5s48/NUvev76CEQ/jmdqL1yMbQlC32bQXn4XxFXKCLPFLzeIFMd3lslusw8sOHca+MabVtsmHM7ibZsXZ9Cba4nQLdyR2b0Bkrx+rNydym7Z3LXMXK5wXIeEoiBmvKp9bk9Lcb1SiFLjr3yoDmPh1x5Z/k/AgMBAAECgYEAgAjVohypOPDraiL40hP/7/e1qu6mQyvcgugVcYTUmvK64U7HYHNpsyQI4eTRq1f91vHt34a2DA3K3Phzifst/RoonlMmugXg/Klr5nOXNBZhVO6i5XQ3945dUeEq7LhiJTTv0cokiCmezgdmrW8n1STZ/b5y5MIOut8Y1rwOkAECQQC+an4ako+nPNw72kM6osRT/qC589AyOav60F1bHonK6NWzWOMiFekGuvtpybgwt4jbpQxXXRPxvJkgBq873fwBAkEAupGaEcuqXtO2j0hJFOG5t+nwwnOaJF49LypboN0RX5v8nop301//P16Bs/irj5F/mAs9lFR4GZ3bxL8zs5r1PwJBALa1MDMHFlf+CcRUddW5gHCoDkjfLZJDzEVp0WoxLz5Hk2X3kFmQdHxExiCHsfjs4qD/CYx6fzyhHrygLVxgcAECQAT8z3maUDuovUCnVgzQ2/4mquEH5h8Cxe/02e46+rPrn509ZmaoMlKnXCBLjYqRATA3XLYSbAODTNS9p8wtYFECQHa/xgB+nYWoevPC/geObOLAP9HMdNVcIAJq2rgeXVI4P7cFXvksRborHmjuy1fltoR0003qlSg82mxzABbzYUs=
#易宝公玥
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCj4k0oTc05UzrvBB6g24wsKawTlIX5995q3CQYrgM5un9mKEQc/NQIsJqqG2RUHyXUIBogMaMq
G1F1QPoKMaXeVfVUSYa8ZU7bV9rOMDUT20BxAmPbtLlWdTSXDxXKXQxwkyfUAih1ZgTLI3vYg3flHeUA6cZRdbwDPLqXle8SIwIDAQAB
*
*/
/*
//测试配置号
$config = array(
    'merchantAccount' => 'YB01000000144',
    'merchantPublicKey' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDxhOgx8q1FAIKnqf6BqjCLKyXXSTRSNSfwS9Nc6E2ffmIpbieyN7mB7XqQKY/icnOB34vtPAjEmQUx4uc1h5R0ApdFm3RJEsWokV/beGjEtd1i2EoSgYwGSXaC32ExpcmsPrZu1hvzEflVmpJD19KcXxvnbmQEHiA6AS1Xy/vooQIDAQAB',
    'merchantPrivateKey' => 'MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAPGE6DHyrUUAgqep/oGqMIsrJddJNFI1J/BL01zoTZ9+YiluJ7I3uYHtepApj+Jyc4Hfi+08CMSZBTHi5zWHlHQCl0WbdEkSxaiRX9t4aMS13WLYShKBjAZJdoLfYTGlyaw+tm7WG/MR+VWakkPX0pxfG+duZAQeIDoBLVfL++ihAgMBAAECgYAw2urBV862+5BybA/AmPWy4SqJbxR3YKtQj3YVACTbk4w1x0OeaGlNIAW/7bheXTqCVf8PISrA4hdL7RNKH7/mhxoX3sDuCO5nsI4Dj5xF24CymFaSRmvbiKU0Ylso2xAWDZqEs4Le/eDZKSy4LfXA17mxHpMBkzQffDMtiAGBpQJBAPn3mcAwZwzS4wjXldJ+Zoa5pwu1ZRH9fGNYkvhMTp9I9cf3wqJUN+fVPC6TIgLWyDf88XgFfjilNKNz0c/aGGcCQQD3WRxwots1lDcUhS4dpOYYnN3moKNgB07Hkpxkm+bw7xvjjHqI8q/4Jiou16eQURG+hlBZlZz37Y7P+PHF2XG3AkAyng/1WhfUAfRVewpsuIncaEXKWi4gSXthxrLkMteM68JRfvtb0cAMYyKvr72oY4Phyoe/LSWVJOcW3kIzW8+rAkBWekhQNRARBnXPbdS2to1f85A9btJP454udlrJbhxrBh4pC1dYBAlz59v9rpY+Ban/g7QZ7g4IPH0exzm4Y5K3AkBjEVxIKzb2sPDe34Aa6Qd/p6YpG9G6ND0afY+m5phBhH+rNkfYFkr98cBqjDm6NFhT7+CmRrF903gDQZmxCspY',
    'yeepayPublicKey' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCxnYJL7fH7DVsS920LOqCu8ZzebCc78MMGImzW8MaP/cmBGd57Cw7aRTmdJxFD6jj6lrSfprXIcT7ZXoGL5EYxWUTQGRsl4HZsr1AlaOKxT5UnsuEhA/K1dN1eA4lBpNCRHf9+XDlmqVBUguhNzy6nfNjb2aGE+hkxPP99I1iMlQIDAQAB'
);
*/


$config = array(
    'merchantAccount' => '10000419568',
    'merchantPublicKey' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCKxayKB/TqDXtcKaObOPPzVL3r++ghEP45nai9cjG0JQt9m0F5+F8RVygizxS83iBTHd5bJbrMPLDh3GvjGm1bbJhzO4m2bF2fQm2uJ0C3ckdm9AZK8fqzcncpu2dy1zFyucFyHhKIgZryqfW5PS3G9UohS4698qA5j4dceWf5PwIDAQAB',
    'merchantPrivateKey' => 'MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAIrFrIoH9OoNe1wpo5s48/NUvev76CEQ/jmdqL1yMbQlC32bQXn4XxFXKCLPFLzeIFMd3lslusw8sOHca+MabVtsmHM7ibZsXZ9Cba4nQLdyR2b0Bkrx+rNydym7Z3LXMXK5wXIeEoiBmvKp9bk9Lcb1SiFLjr3yoDmPh1x5Z/k/AgMBAAECgYEAgAjVohypOPDraiL40hP/7/e1qu6mQyvcgugVcYTUmvK64U7HYHNpsyQI4eTRq1f91vHt34a2DA3K3Phzifst/RoonlMmugXg/Klr5nOXNBZhVO6i5XQ3945dUeEq7LhiJTTv0cokiCmezgdmrW8n1STZ/b5y5MIOut8Y1rwOkAECQQC+an4ako+nPNw72kM6osRT/qC589AyOav60F1bHonK6NWzWOMiFekGuvtpybgwt4jbpQxXXRPxvJkgBq873fwBAkEAupGaEcuqXtO2j0hJFOG5t+nwwnOaJF49LypboN0RX5v8nop301//P16Bs/irj5F/mAs9lFR4GZ3bxL8zs5r1PwJBALa1MDMHFlf+CcRUddW5gHCoDkjfLZJDzEVp0WoxLz5Hk2X3kFmQdHxExiCHsfjs4qD/CYx6fzyhHrygLVxgcAECQAT8z3maUDuovUCnVgzQ2/4mquEH5h8Cxe/02e46+rPrn509ZmaoMlKnXCBLjYqRATA3XLYSbAODTNS9p8wtYFECQHa/xgB+nYWoevPC/geObOLAP9HMdNVcIAJq2rgeXVI4P7cFXvksRborHmjuy1fltoR0003qlSg82mxzABbzYUs=',
    'yeepayPublicKey' => 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCj4k0oTc05UzrvBB6g24wsKawTlIX5995q3CQYrgM5un9mKEQc/NQIsJqqG2RUHyXUIBogMaMqG1F1QPoKMaXeVfVUSYa8ZU7bV9rOMDUT20BxAmPbtLlWdTSXDxXKXQxwkyfUAih1ZgTLI3vYg3flHeUA6cZRdbwDPLqXle8SIwIDAQAB'
);



include 'yeepay/yeepay.class.php';
$yeepay = new yeepay($config);


//生产环境访问地址  https://ok.yeepay.com/paymobile/api/pay/request 请求方式	POST
//测试环境访问地址：http://mobiletest.yeepay.com/payweb/api/pay/request
$merchantaccount 	= 	$config['merchantAccount'];
$orderid 			=	$yeepay->random( 18 );					//最长50
$transtime			=	time();					                //交易时间
$currency			=	156;
$amount				=	1;										//分为单位整型，大于零
$productcatalog		=	'30';										//商品类别码  
$productname		=	'诛仙-阶成品天琊';						//最长50 推荐 应用-商品  格式
$productdesc		=	'诛仙3阶成品天琊';					//最长200
$identityid			=	'userid_username';						//最长50 商户生成的用户账号唯一标识
$identitytype		=	2;										//0：IMEI 1：MAC地址 2：用户 ID  3：用户 Email 4：用户手机号 5：用户身份证号 6：用户纸质订单协议号
$terminaltype		=	0;										//int  终端类型 0:IMEI 1:MAC 2:UUID 3 : other
$terminalid			=	'15-06-DC-59-C2-AB';					
$orderexpdate		=	60;										//int 以分为单  订单有效期时间
$userip				=	get_client_ip();							
$userua				=	$_SERVER['HTTP_USER_AGENT'];
$callbackurl		=	get_host().'/CallBack.php';				//用来通知商户支付结果,回调地址 前后台回调地址的回调 内容相同
$fcallbackurl		=	get_host().'/CallBack.php';				//用来通知商户支付结果，用户在网页支付成功页面，点击“返回商户”时的回调地址
$version			=	0;										//目前只支持WAP版，0或不传值
$paytypes			=	'1';										//1|2|3|4   1-借记卡支付 2-信用卡支付 3-手机充值卡支付 4-游戏点卡支付 空则为该商户后台开通的支付方式
$cardno				=	'';										//银行卡号。。
$idcardtype			=	'01';										//证件类型 与证件号，同时为空，或不为空  01:身份证
$idcard				=	'';										//证件号
$owner				=	'';										//持卡人姓名

//提现接口 https://ok.yeepay.com/paypai/api/tzt/withdraw	请求方式	post
$requestid			=	$yeepay->random( 18 );
$card_top			=	'';										//卡前6位
$card_last			=	'';										//卡后4位
$drawtype			=	'NATRALDAY_NORMAL';						//NATRALDAY_NORMAL(自然日+1)   NATRALDAY_URGENT(自然日+0)
$imei				=	'15-06-DC-59-C2A';					//国际移动设备身份码的缩写 是由15位数字组成的“电子串号”
$ua					=	$_SERVER['HTTP_USER_AGENT'];

//查询绑卡信息列表  https://ok.yeepay.com/payapi/api/bankcard/authbind/list  请求方式   GET
//测试环境访问地址：http://mobiletest.yeepay.com/testpayapi/api/bankcard/bind/list 


//提现查询  https://ok.yeepay.com/payapi/api/tzt/drawrecord	请求方式	GET
$ybdrawflowid		=	'';									//易宝流水号


//解除银行卡的绑定	https://ok.yeepay.com/payapi/api/tzt/unbind  POST

//查银行卡信息		https://ok.yeepay.com/payapi/api/bankcard/check

//绑定银行卡		
$username 	=  	'';									//持卡人姓名
$phone		=	'';									//银行预留手机号
$registerphone	=	'';								//用户注册手机号
$registerdate	=	date('Y-m-d H:i:s',time());		//用户注册日期
$registerip		=	get_client_ip();				//用户注册ip
$registeridcardtype	=	'';							//用户注册证件类型
$registeridcardno	=	'';							//用户注册证件号
$registercontact	=	'';							//用户注册联系方式
$os					=	'ios';						//用户使用的操作系统
$idcardno			=	'';							//证件号

//退货退款  https://ok.yeepay.com/merchant/query_server/direct_refund	POST	
$cause				=	'';							//退款说明
$origyborderid		=	'';							//原易宝交易流水号

//交易记录查询	https://ok.yeepay.com/merchant/query_server/pay_single	GET
$yborderid			=	'';							//易宝流水号

//退款退货记录查询  https://ok.yeepay.com/merchant/query_server/refund_single	GET

//按时间段获取消费清算对账单	https://ok.yeepay.com/merchant/query_server/pay_clear_data	GET
$startdate			=	date('Y-m-d',time());						//获取消费清算对账记录开始时间 格式:2014-03-07
$enddate			=	date('Y-m-d',time());						//获取消费清算对账记录结束时间 格式:2014-03-07

//按时间段获取退款清算对账记录	https://ok.yeepay.com/merchant/query_server/refund_clear_data	GET









/******************************** 公用参数方法 ********************************************************/
// 获取客户端IP地址
function get_client_ip()
{
    if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
        $ip = getenv("HTTP_CLIENT_IP");
    else
        if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"),
            "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        else
            if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
                $ip = getenv("REMOTE_ADDR");
            else
                if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'],
                    "unknown"))
                    $ip = $_SERVER['REMOTE_ADDR'];
                else
                    $ip = "unknown";
    return ($ip);
}
//获取当前域名
function get_host(){
		$current_domain = !empty($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:$_SERVER['HTTP_HOST'];
		if(!stripos($current_domain,'http://')){
					$current_domain = 'http://'.$current_domain;
		}
		return $current_domain;
}
//字符或数字，字数限制
function paramLimit( $isparam='',$num=100 ){
		 if(empty($isparam))
					return $isparam;
		 $type = gettype( $isparam );
		 $isparam = substr( $isparam,0,$num );
		 if($type=='integer'){
				(integer)$isparam;
		 }elseif($type=='int'){
				(int)$isparam;
		 }	 
		 return $isparam;
}


?>
