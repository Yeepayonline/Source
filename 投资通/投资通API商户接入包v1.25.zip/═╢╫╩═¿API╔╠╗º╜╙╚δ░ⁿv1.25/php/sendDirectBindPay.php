<?php
//4.3 支付接口--不发送短验
include 'config.php';
include 'yeepay/yeepayMPay.php';

$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);

$order_id       =  trim($_POST['orderid']);
$amount         =  intval($_POST['amount']);
$transtime      =  intval($_POST['transtime']);
$product_name   =  trim($_POST['productname']);
$product_desc   =  trim($_POST['productdesc']);
$identity_type  =  intval($_POST['identitytype']);
$identity_id    =  trim($_POST['identityid']);
$user_ip        =  trim($_POST['userip']);
$card_top       =  trim($_POST['card_top']);
$card_last      =  trim($_POST['card_last']);
$callbackurl    =  trim($_POST['callbackurl']);
$currency       =  intval($_POST['currency']);
$orderexpdate   =  intval($_POST['orderexpdate']);
$imei           =  trim($_POST['imei']);
$ua             =  trim($_POST['ua']);


$data = $yeepay->directBindPay($order_id,$transtime,$amount,$identity_id,$identity_type,$user_ip,$card_top,$card_last,$callbackurl,
$currency,$product_name,$product_desc,$orderexpdate,$imei,$ua);

if( array_key_exists('error_code', $data))	
return;

 ?> 


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>4.3 支付接口--不发送短验</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
			   4.3 支付接口--不发送短验
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left">  <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户订单号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['orderid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">orderid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;易宝交易流水号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['yborderid'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">yborderid</td> 
			</tr>

     <tr>
				<td width="15%" align="left">&nbsp;交易金额</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['amount'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">amount</td> 
			</tr>
		</table>

	</body>
</html>
