﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 查询支付结果
    /// </summary>
    public class QueryPayResult
    {
        /// <summary>
        /// 查询
        /// </summary>
        public void QueryResult()
        {
            //商户交易订单号
            string orderid = "";

            YJPay yjpay = new YJPay();
            //调用sdk请求一键支付接口
            string res = yjpay.queryPayResult(orderid);

            Console.WriteLine("易宝返回结果为：" + res);

            Console.ReadLine();
        }
    }
}
