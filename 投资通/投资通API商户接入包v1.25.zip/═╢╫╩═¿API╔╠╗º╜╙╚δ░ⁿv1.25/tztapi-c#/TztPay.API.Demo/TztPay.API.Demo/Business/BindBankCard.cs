﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 绑定银行卡
    /// </summary>
    public class BindBankCard
    {
        /// <summary>
        /// 绑卡
        /// </summary>
        public void BindCard()
        {

            string requestid = "D" + DateTime.Now.ToString("yyMMddHHmmss");//请求绑卡订单号
            string cardno = "";//请求绑定的银行卡
            string identityid = "";//用户身份标识

            int identitytype = 2;//0：IMEI 1：MAC 地址2：用户 ID3：用户 Email4：用户手机号5：用户身份证号6：用户纸质订单协议号
            string idcardno = "";//证件号
            string username = "";//持卡人姓名
            string phone = "18603009385";//银行卡预留手机号
            string registerphone = "18603009385";//注册预留手机号
            string registerdate = DateTime.Now.ToString("yyyyMMddHHmmss");//注册时间
            string registerip = "172.0.1.1";//所在IP
            string registeridcardno = "";//用 户注 册 证件号
            string registercontact = "wxm";//用 户注 册 联
            string userip = "172.0.1.1";//所在IP
            string os = "";
            string imei = "1OLKHHK_A";
            string ua = "";

            YJPay pay = new YJPay();
            string viewYbResult = pay.bindBankCardRequest(requestid, cardno, identityid, identitytype,
                 idcardno, username, phone, registerphone, registerdate, registerip,
                 registeridcardno, registercontact, userip, os, imei, ua);

            Console.WriteLine("易宝返回的业务数据明文为：" + viewYbResult);


            //将支付请求获得的易宝返回结果反序列化
            SortedDictionary<string, object> sd = (SortedDictionary<string, object>)Newtonsoft.Json.JsonConvert.DeserializeObject(viewYbResult, typeof(SortedDictionary<string, object>));

            //请求成功才要走下面的流程
            if (sd != null && sd.ContainsKey("requestid"))
            {
                string codesender = "";//发送短信方式
                string validatecode = "";
                if (sd.ContainsKey("codesender"))
                {
                    codesender = sd["codesender"].ToString().ToUpper();
                }

                //商户发送直接接收，其他都是短信发送要输入
                if (codesender == "MERCHANT")
                {
                    validatecode = sd["smscode"].ToString();//
                }
                else
                {
                    Console.WriteLine("");
                    Console.WriteLine("请输入接收到的短信验证码：");
                    validatecode = Console.ReadLine();
                }
                ConfirmBindBankCard(requestid, validatecode);


            }

            Console.ReadLine();

        }

        /// <summary>
        /// 确认绑卡操作
        /// </summary>
        /// <param name="requestid">绑卡请求订单号</param>
        /// <param name="validatecode">验证码</param>
        public void ConfirmBindBankCard(string requestid, string validatecode)
        {
            YJPay pay = new YJPay();
            string viewYbResult = pay.confirmBindBankCard(requestid, validatecode);

            Console.WriteLine("确认绑卡易宝返回的业务数据明文为：" + viewYbResult);
        }
    }
}
