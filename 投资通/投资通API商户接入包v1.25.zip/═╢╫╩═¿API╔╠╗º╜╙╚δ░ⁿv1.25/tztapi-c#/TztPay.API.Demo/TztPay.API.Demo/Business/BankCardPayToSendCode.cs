﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 绑定支付，需要发送短信验证码
    /// </summary>
    public class BankCardPayToSendCode
    {
        /// <summary>
        /// 绑定支付
        /// </summary>
        public void BindPay()
        {
            int amount = 1;//支付金额为分

            string identityid = "";//用户身份标识
            int identitytype = 2;//0：IMEI 1：MAC 地址2：用户 ID3：用户 Email4：用户手机号5：用户身份证号6：用户纸质订单协议号
            Random ra = new Random();
            string orderid = "1234567" + 50 * ra.Next();
            string imei = "05-16-DC-59-C2-34";// 终端硬件标识，MAC地址或者IMEI
            string productdesc = "植物大战僵尸道具";//描述
            string productname = "玉米加农炮";//商品名称
            string card_top = "";//银行卡前6位
            string card_last = "";//银行卡后4位

            int orderexpdate = 60;//订单有效时间

            DateTime t1 = DateTime.Now;
            DateTime t2 = new DateTime(1970, 1, 1);
            double t = t1.Subtract(t2).TotalSeconds;
            int transtime = (int)t;//交易时间

            string userip = "";
            //商户提供的商户后台系统异步支付回调地址
            string callbackurl = "";
            string ua = "";
            YJPay yjpay = new YJPay();
            //step1:调用sdk请求一键支付接口
            string payres = yjpay.requestBindPayToSendCode(amount, orderexpdate, identityid, identitytype, orderid, imei, ua
                , productdesc, productname, transtime, userip, callbackurl, card_top, card_last);

            Console.WriteLine("易宝绑卡支付请求接口返回结果为：" + payres);

            //将支付请求获得的易宝返回结果反序列化
            SortedDictionary<string, object> payresSD = (SortedDictionary<string, object>)Newtonsoft.Json.JsonConvert.DeserializeObject(payres, typeof(SortedDictionary<string, object>));

            //有短信确认字段表示成功才需要继续
            if (payresSD.ContainsKey("smsconfirm"))
            {
                //获取是否需要短信校验的建议
                string s = payresSD["smsconfirm"].ToString();

                if (s == "0")
                {
                    //step2:易宝建议无需短信校验，直接调用确认支付接口
                    string confirmpayjson = yjpay.confirmPay(orderid, null);
                    Console.WriteLine("易宝建议无需短信校验，直接调用确认支付接口返回的结果：" + confirmpayjson);
                }
                else if (s == "1")
                {
                    string codesender = payresSD["codesender"].ToString().ToUpper();//发送验证码方

                    string validatecode = "";

                    //易宝发送
                    if (codesender == "YEEPAY")
                    {
                        //step2:易宝建议需要短信校验，调用易宝向用户发生短信校验接口。用户在商户的交互页面输入验证码后才能调用确认支付接口
                        string validatecodejson = yjpay.sendValidateCode(orderid);
                        Console.WriteLine("易宝建议需要短信校验，调用发送短信验证码接口返回的结果：" + validatecodejson);
                        validatecode = "123456";

                        //Console.WriteLine("");
                        //Console.WriteLine("请输入短信验证码:");
                        //validatecode = Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("");
                        Console.WriteLine("请输入短信验证码:");
                        validatecode = Console.ReadLine();
                    }
                    //step3:确认支付
                    string confirmpayjson2 = yjpay.confirmPay(orderid, validatecode);
                    Console.WriteLine("易宝建议需要短信校验，调用确认支付接口返回的结果：" + confirmpayjson2);
                }

            }
            Console.ReadLine();
        }
    }
}
