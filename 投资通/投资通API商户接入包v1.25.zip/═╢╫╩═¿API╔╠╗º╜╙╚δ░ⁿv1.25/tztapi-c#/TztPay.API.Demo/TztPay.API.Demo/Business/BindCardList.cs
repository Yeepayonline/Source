﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 获取绑卡数据列表
    /// </summary>
    public class BindBankCardList
    {
        public void GetBindCardList()
        {
            string identityid = "";//用户身份标识
            int identitytype = 2;//0：IMEI 1：MAC 地址2：用户 ID3：用户 Email4：用户手机号5：用户身份证号6：用户纸质订单协议号

            YJPay yjpay = new YJPay();
            //调用sdk请求一键支付接口
            string res = yjpay.getBindList(identityid, identitytype);

            Console.WriteLine("易宝返回结果为：" + res);

            Console.ReadLine();
        }
    }
}
