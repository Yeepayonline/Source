﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 绑定银行卡查询
    /// </summary>
    public class QueryBankCard
    {
        /// <summary>
        /// 查询绑定
        /// </summary>
        public void QueryCard()
        {

            string cardno = "";//要查询的银行卡号

            string viewYbResult = new YJPay().bankCardCheck(cardno);

            Console.WriteLine("易宝返回的业务数据明文为：" + viewYbResult);

            Console.ReadLine();
        }
    }
}
