﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 提现请求
    /// </summary>
    public class WithDraw
    { /// <summary>
      /// 提现请求操作
      /// </summary>
        public void DrawRecordRequest()
        {
            string requestid = "";// +DateTime.Now.ToString("yyMMddHHmmss");//请求绑卡订单号
            string card_top = "";//提现卡前6位 
            string card_last = "";//后4位
            string identityid = "";//用户身份标识
            int amount = 1;//提现金额单位分
            int identitytype = 2;//0：IMEI 1：MAC 地址2：用户 ID3：用户 Email4：用户手机号5：用户身份证号6：用户纸质订单协议号
            string drawtype = "NATRALDAY_NORMAL";//提现类型 NATRALDAY_NORMAL  自 然 日t+1; NATRALDAY_URGENT （自然日 t+0
            string userip = "172.0.1.1";//所在IP
            string imei = "";
            string ua = "";

            YJPay pay = new YJPay();
            string viewYbResult = pay.requestDrawRecord(requestid, identityid,
             identitytype, card_top, card_last, amount, drawtype, imei, userip, ua);

            //SoftLog.LogStr("提现请求结果:" + viewYbResult, "tixian");

            Console.WriteLine("易宝返回的业务数据明文为：" + viewYbResult);

            Console.ReadLine();
        }
    }
}
