﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 接口配置相关
    /// </summary>
    class APIURLConfig
    {
        static APIURLConfig()
        {
            //一键支付API前缀
            apiprefix = "https://ok.yeepay.com";

            //商户通用接口前缀
            merchantPrefix = "http://ok.yeepay.com/merchant";

            //绑定银行卡https://ok.yeepay.com/payapi/api/tzt/invokebindbankcard
            bindBankCardURI = "/payapi/api/tzt/invokebindbankcard";

            //银行卡绑定检查https://ok.yeepay.com
            bankcardCheckURI = "/payapi/api/bankcard/check";

            //获取绑卡列表
            bindlistURI = "/payapi/api/bankcard/bind/list";

            //提现查询https://ok.yeepay.com/payapi/api/tzt/drawrecord
            drawRecordURI = "/payapi/api/tzt/drawrecord";

            //提现接口https://ok.yeepay.com/payapi/api/tzt/withdraw
            withdrwURI = "/payapi/api/tzt/withdraw";

            //确认 银行绑卡https://ok.yeepay.com/payapi/api/tzt/confirmbindbankcard
            confrimBindBankCardURI = "/payapi/api/tzt/confirmbindbankcard";


            //绑定支付发送短信的https://ok.yeepay.com/payapi/api/tzt/pay/validatecode/send
            bindPaySendCodeURI = "/payapi/api/tzt/pay/validatecode/send";


            //确认支付 https://ok.yeepay.com/payapi/api/tzt/pay/confirm/validatecode
            confirmPayURI = "/payapi/api/tzt/pay/confirm/validatecode";

            //发生短信验证码接口 https://ok.yeepay.com/payapi/api/tzt/pay/validatecode/send
            sendValidateCodeURI = "/payapi/api/tzt/pay/validatecode/send";

            //绑卡支付接口https://ok.yeepay.com/payapi/api/tzt/directbindpay
            bindpayURI = "/payapi/api/tzt/directbindpay";

            //绑定支付需求发送短信验证码https://ok.yeepay.com//payapi/api/tzt/pay/bind/reuqest
            bindPayToSendCodeURI = "/payapi/api/tzt/pay/bind/reuqest";


            //支付结果查询接口 https://ok.yeepay.com/payapi/api/query/order
            queryPayResultURI = "/payapi/api/query/order";




            //直接退款
            directFundURI = "/query_server/direct_refund";

            //交易记录查询
            queryOrderURI = "/query_server/pay_single";

            //退款订单查询
            queryRefundURI = "/query_server/refund_single";

            //获取消费清算单
            clearPayDataURI = "/query_server/pay_clear_data";

            //获取退款清算单
            clearRefundDataURI = "/query_server/refund_clear_data";

            //借记卡支付接口
            //debitpayURI = "/api/bankcard/debit/pay/request";

            //信用卡支付接口
            //creditpayURI = "/api/bankcard/credit/pay/request";
        }

        /// <summary>
        /// 接口地址前缀
        /// </summary>
        public static string apiprefix
        { get; set; }

        /// <summary>
        /// 商户通用接口前缀
        /// </summary>
        public static string merchantPrefix
        { get; set; }

        /// <summary>
        /// 绑定银行卡
        /// </summary>
        public static string bindBankCardURI { get; set; }

        /// <summary>
        /// 银行卡信息查询
        /// </summary>
        public static string bankcardCheckURI
        { get; set; }

        /// <summary>
        /// 绑定银行卡列表查询
        /// </summary>
        public static string bindlistURI
        { get; set; }

        /// <summary>
        /// 绑定支付，需要发送短信验证码的
        /// </summary>
        public static string bindPayToSendCodeURI { get; set; }

        /// <summary>
        /// 提现结果查询
        /// </summary>
        public static string drawRecordURI
        { get; set; }

        /// <summary>
        /// 提现接口
        /// </summary>
        public static string withdrwURI { get; set; }

        /// <summary>
        /// 确认绑定银卡接口
        /// </summary>
        public static string confrimBindBankCardURI { get; set; }

        /// <summary>
        /// 支付需要发送短信验证码接口
        /// </summary>
        public static string bindPaySendCodeURI { get; set; }

        /// <summary>
        /// 确认支付
        /// </summary>
        public static string confirmPayURI
        { get; set; }

        /// <summary>
        /// 发送短信验证码
        /// </summary>
        public static string sendValidateCodeURI
        { get; set; }


        /// <summary>
        /// 绑定支付（不发短信）
        /// </summary>
        public static string bindpayURI
        { get; set; }

        /// <summary>
        /// 查询支付结果
        /// </summary>
        public static string queryPayResultURI
        { get; set; }




        /// <summary>
        /// 直接退款
        /// </summary>
        public static string directFundURI
        { get; set; }

        /// <summary>
        /// 交易记录查询
        /// </summary>
        public static string queryOrderURI
        { get; set; }

        /// <summary>
        /// 退款记录查询
        /// </summary>
        public static string queryRefundURI
        { get; set; }


        /// <summary>
        /// 获取支付清单
        /// </summary>
        public static string clearPayDataURI
        { get; set; }

        /// <summary>
        /// 获取退款清单
        /// </summary>
        public static string clearRefundDataURI
        { get; set; }
    }
}
