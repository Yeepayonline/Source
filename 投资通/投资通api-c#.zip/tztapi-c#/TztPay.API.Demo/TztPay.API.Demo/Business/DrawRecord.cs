﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 提现结果查询
    /// </summary>
    public class DrawRecord
    {


        /// <summary>
        /// 提现结果查询
        /// </summary>
        public void QueryDrawRecordResult()
        {
            string requestid = "";//商户订单号
            string ybdrawflowid = "";//易宝流水号
            YJPay yjpay = new YJPay();
            //调用sdk请求一键支付接口
            string res = yjpay.queryWithDrawResult(requestid, ybdrawflowid);

            Console.WriteLine("易宝返回结果为：" + res);

            Console.ReadLine();
        }
    }
}
