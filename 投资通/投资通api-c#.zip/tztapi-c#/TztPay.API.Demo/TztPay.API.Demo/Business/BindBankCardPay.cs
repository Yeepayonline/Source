﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payapi_demo
{
    /// <summary>
    /// 绑定支付不需要发送短信验证码
    /// </summary>
    public class BindBankCardPay
    {
        /// <summary>
        /// 绑定支付
        /// </summary>
        public void BindPay()
        {
            int amount = 1;//支付金额为分

            string identityid = "";//用户身份标识
            int identitytype = 2;//0：IMEI 1：MAC 地址2：用户 ID3：用户 Email4：用户手机号5：用户身份证号6：用户纸质订单协议号
            Random ra = new Random();
            string orderid = "1234567" + 50 * ra.Next();
            string imei = "05-16-DC-59-C2-34";// 终端硬件标识，MAC地址或者IMEI
            string productdesc = "植物大战僵尸道具";//描述
            string productname = "玉米加农炮";//商品名称
            string card_top = "";//银行卡前6位
            string card_last = "";//银行卡后4位

            int orderexpdate = 60;//订单有效时间

            DateTime t1 = DateTime.Now;
            DateTime t2 = new DateTime(1970, 1, 1);
            double t = t1.Subtract(t2).TotalSeconds;
            int transtime = (int)t;//交易时间

            string userip = "";
            //商户提供的商户后台系统异步支付回调地址
            string callbackurl = "";
            string ua = "";
            YJPay yjpay = new YJPay();
            //step1:调用sdk请求一键支付接口
            string payres = yjpay.requestBindPay(amount, orderexpdate, identityid, identitytype, orderid, imei, ua
                , productdesc, productname, transtime, userip, callbackurl, card_top, card_last);

            Console.WriteLine("易宝绑卡支付请求接口返回结果为：" + payres);

            Console.ReadLine();
        }
    }
}
