﻿using payapi_demo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TztPay.API.Demo
{
    class Program
    {
        static void Main(string[] args)
        {


            //绑卡测试
            //new BindBankCard().BindCard(); 

            //绑卡支付（需要发送短信）
            //new BankCardPayToSendCode().BindPay(); 

            //绑卡支付不需要短信验证码
            //new BindBankCardPay().BindPay(); //测试通过orderid":"1234567 - 19961810","yborderid":"411506235615140967"

            //查询银行卡绑定信息
            //new QueryBankCard().QueryCard(); 


            //绑定银行卡列表信息获取
            //new BindBankCardList().GetBindCardList(); 

            //提现请求
            //new WithDraw().DrawRecordRequest();


            //提现查询
            //new DrawRecord().QueryDrawRecordResult();

            //查询支付结果
            //new QueryPayResult().QueryResult();



        }
    }
}
