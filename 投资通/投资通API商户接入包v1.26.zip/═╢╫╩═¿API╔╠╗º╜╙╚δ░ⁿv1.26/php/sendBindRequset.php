<?php
include 'config.php';
include 'yeepay/yeepayMPay.php';

$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);

$requestid        =  trim($_POST['requestid']);
$cardno           =  trim($_POST['cardno']);
$idcardtype       =  trim($_POST['idcardtype']);
$idcardno         =  trim($_POST['idcardno']);
$username         =  trim($_POST['username']);
$phone            =  trim($_POST['phone']);
$identity_type    =  intval($_POST['identitytype']);
$identity_id      =  trim($_POST['identityid']);
$user_ip          =  trim($_POST['userip']);
$advicesmstype    =  trim($_POST['advicesmstype']);
$registerphone    =  trim($_POST['registerphone']);
$registerdate     =  trim($_POST['registerdate']);
$registerip       =  trim($_POST['registerip']);
$registeridcardtype= trim($_POST['registeridcardtype']);
$registeridcardno =  trim($_POST['registeridcardno']);
$registercontact  =  trim($_POST['registercontact']);
$os               =  trim($_POST['os']);
$imei             =  trim($_POST['imei']);
$ua               =  trim($_POST['ua']);


$data = $yeepay->bindCardRequest($cardno,$idcardtype,$idcardno,$username,$phone,$requestid,$identity_id,$identity_type,$advicesmstype,$registerphone,$registerdate,
$registerip,$registeridcardtype,$registeridcardno,$registercontact,$os,$user_ip,$imei,$ua);

if( array_key_exists('error_code', $data))	
return;

 ?> 


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>4.1.1  绑卡请求</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
					4.1.1  绑卡请求
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left">  <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;绑卡请求号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['requestid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">requestid</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;短信验证码发送方</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"><?php echo $data['codesender'];?></td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">codesender</td> 
			</tr>

			<tr>
				<td width="15%" align="left" rowspan="6">&nbsp;短信验证码</td>
				<td width="5%"  align="center" rowspan="6"> : </td> 
				<td width="60%" align="left" rowspan="6">
					<?php 
					 if( empty($data['smscode']))
					 {echo '';}
					 else
					 {echo $data['smscode'];}
					 ?> 
					<span style="font-size:12px; color:#FF0000; font-weight:100;"> 
						-  只有配置商户短验才会有返回值
					</span>
				</td>
				<td width="5%"  align="center" rowspan="6"> - </td> 
				<td width="25%" align="left" rowspan="6">smscode</td> 
			</tr>

		</table>

	</body>
</html>
