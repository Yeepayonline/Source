<?php

// 提现
include("yeepay/yeepayMPay.php");
include("config.php");
$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);
$requestid     =  trim($_POST['requestid']);
$identityid    = trim($_POST['identityid']);
$identitytype  = intval($_POST['identitytype']);
$card_top      = trim($_POST['card_top']);
$card_last     = trim($_POST['card_last']);
$amount        = intval($_POST['amount']);
$currency      = intval($_POST['currency']);
$imei          = trim($_POST['imei']);
$drawtype      = trim($_POST['drawtype']);
$userip        = trim($_POST['userip']);
$ua		         = trim($_POST['ua']);
$callbackurl   = trim($_POST['callbackurl']);
$data = $yeepay->withdraw($requestid,$identityid, $identitytype,$card_top,$card_last,$amount,$currency,$drawtype,$imei,$userip,$ua,$callbackurl);

if( array_key_exists('error_code', $data))	
return;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>4.5 提现接口</title>
</head>
	<body>
		<br /> <br />
		<table width="70%" border="0" align="center" cellpadding="5" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
			  4.5 提现接口
				</th>
		  	</tr>

			<tr>
				<td width="25%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $merchantaccount;?>  </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="25%" align="left">&nbsp;提现请求号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['requestid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">requestid</td> 
			</tr>

			<tr>
				<td width="25%" align="left">&nbsp;易宝流水号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['ybdrawflowid'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">ybdrawflowid</td> 
			</tr>


			<tr>
				<td width="25%" align="left">&nbsp;提现金额「分」</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['amount'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">amount</td> 
			</tr>

			<tr>
				<td width="25%" align="left">&nbsp;卡号前 6 位</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left">  <?php echo $data['card_top'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">card_top</td> 
			</tr>

			<tr>
				<td width="25%" align="left">&nbsp;卡号后4位</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['card_last'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">card_last</td> 
			</tr>

			<tr>
				<td width="25%" align="left">&nbsp;提现请求状态</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['status'];?>  </td>
				<td width="5%"  align="center"> - </td> 
				<td width="15%" align="left">status</td> 
			</tr>

		</table>

	</body>
</html>