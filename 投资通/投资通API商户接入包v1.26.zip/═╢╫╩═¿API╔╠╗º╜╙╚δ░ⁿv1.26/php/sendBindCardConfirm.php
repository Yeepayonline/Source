<?php
//确认绑卡
include("yeepay/yeepayMPay.php");
include("config.php");
$yeepay = new yeepayMPay($merchantaccount,$merchantPublicKey,$merchantPrivateKey,$yeepayPublicKey);
$requestid = trim($_POST['requestid']);
$validatecode = trim($_POST['validatecode']);
$data = $yeepay->bindCardConfirm($requestid,$validatecode);
if( array_key_exists('error_code', $data))	
return;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>4.1.2  确认绑卡</title>
</head>
	<body>
		<br /> <br />
		<table width="80%" border="0" align="center" cellpadding="10" cellspacing="0" 
							style="word-break:break-all; border:solid 1px #107929">
			<tr>
		  		<th align="center" height="30" colspan="5" bgcolor="#6BBE18">
					4.1.2  确认绑卡
				</th>
		  	</tr>

			<tr>
				<td width="15%" align="left">&nbsp;商户编号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $merchantaccount;?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">merchantaccount</td> 
			</tr>

			<tr>
				<td width="15%" align="left">&nbsp;绑卡请求号</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['requestid'];?>  </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">requestid</td> 
			</tr>
		
			<tr>
				<td width="15%" align="left">&nbsp;银行编码</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['bankcode'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">bankcode</td> 
			</tr>
		<tr>
				<td width="15%" align="left">&nbsp;卡号前6位</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['card_top'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">card_top</td> 
			</tr>
					<tr>
				<td width="15%" align="left">&nbsp;卡号后4位</td>
				<td width="5%"  align="center"> : </td> 
				<td width="50%" align="left"> <?php echo $data['card_last'];?> </td>
				<td width="5%"  align="center"> - </td> 
				<td width="25%" align="left">card_last</td> 
			</tr>
			
		</table>

	</body>
</html>
