1、当前仅有java版demo。

2、源代码在demo的该目录下：
   RealNameVerification-3-demo/WEB-INF/classes/com/yeepay/RealNameVerification.java

3、如何运行demo：将文件夹[RealNameVerification-4-demo]复制到tomcat下的webapps文件下，重启tomcat，浏览器中直接访问http://localhost:端口号/RealNameVerification-4-demo

4、测试商编位置：RealNameVerification-3-demo/WEB-INF/classes/merchantInfo.properties
