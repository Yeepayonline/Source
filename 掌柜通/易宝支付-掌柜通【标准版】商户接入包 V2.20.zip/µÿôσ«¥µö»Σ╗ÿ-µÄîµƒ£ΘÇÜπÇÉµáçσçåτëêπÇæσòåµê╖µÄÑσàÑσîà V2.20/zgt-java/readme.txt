1、JAVA版demo运行：将文件夹放在tomcat的webapps目录下即可；然后启动tomcat，在浏览器中敲入：http://localhost:端口号/zgt-java，即可运行demo。

2、JAVA版的源代码放在该目录下：zgt-java/WEB-INF/classes/com/yeepay/ZGTService.java

3、测试商编位置：zgt-java/WEB-INF/classes/merchantInfo.properties
